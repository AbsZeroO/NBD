package org.example.exceptions;

public class RentException extends Exception {
    public RentException(String message) {
        super(message);
    }
}
