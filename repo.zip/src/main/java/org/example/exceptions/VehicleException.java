package org.example.exceptions;

public class VehicleException extends Exception {
    public VehicleException(String message) {
        super(message);
    }
}
